**Name**: Yannick Schlude, David Schmidt
**Seminargruppe**: CS-22-1
**Versuch**: RS-Latch / D-Flipflop

# Aufgabe 1

**Aufgabe**: Bauen Sie einen RS-Latch mit einem TTL-Schaltkreis (*74HC02*). Messen Sie dann die Ausgangsspannungen $Q$ und $!Q$. Visualisieren Sie anschließend die Spannungen bzw. die Zustände mittels einer Leutdiode.

**Vorbereitung**: 
Kenngrößen:
- **Betriebsspannung**: 5V
- **Kurzschlussspannung**: 0.2V
- **Leutdiode**
	- $I_{max}=10mA$
	- $U_{rot}=1.6V$

Geräte:
- Multimeter
- Netzgerät
- Steckbrettelektronikbauteile

%% **TODO** grafik von 74HC02%%

**Versuchsanordnung**

![[schaltdings.png]]

**Durchführung**

Als Erstes wurde der Stromkreis aufgebaut und überprüft, ob dieser fehlerfrei ist. Dann haben wir den Stromkreis angeschlossen und geprüft ob die Ausgangsspannung mit dem Multimeter gemessen.

Die Arbeitstabelle des Stromkreises:

|S|R|$Q$|$!Q$|
|---|---|---|---|
|$0$|$0$|$Q_{n-1}$|$!Q_{n-1}$|
|$0$|$1$|$0$|1|
|$1$|$0$|$1$|$0$|
|$1$|$1$|$X$|$X$|

Mit $X$ ist gemeint, dass die Eingangskombination **verboten** ist. In diesem Zustand wären $Q$ und $!Q$ gleich, was nach Definition nicht sein kann. 

**Auswertung**

$S$ und $R$ 
