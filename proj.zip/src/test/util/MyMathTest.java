package test.util;

import main.util.MyMath;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MyMathTest {

    @Test
    void my_fibonacci_test() {
        assertEquals(MyMath.fibonacci(0), 0);
        assertEquals(MyMath.fibonacci(7), 13);
    }
}