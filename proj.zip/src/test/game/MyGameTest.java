package test.game;

import static org.junit.jupiter.api.Assertions.*;

class MyGameTest {

}