package main.util;

public class MyMath {
    public static int fibonacci(int iterations) {
        int current = 1;
        int last = 0;

        while(iterations > 0) {
            current += last;
            last = current - last;
            iterations--;
        }

        return last;
    }

    public static int add(int num1, int num2) {
        return num1 + num2;
    }

    public static void main(String[] args) {
        for(int i = 0; i < 25; i++) {
            System.out.println(fibonacci(i));
        }
    }
}
